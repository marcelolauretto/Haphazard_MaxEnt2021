### RERANDOMIZATION ADAPTED BY MARCELO LAURETTO 08/Jan/2016 ###

source('genFunctions.r')
source('MultiCore.r')

rerandomize.SSL = function(x, num=1, pw=1/2, normdis='1', gamma1=0.5, gamma2=0.5,
                           pa=NULL, a=NULL, tprocs=NULL, print.progress=TRUE)   {
  #x: can be a list with each element representing a tier of data, a data.frame, a matrix, or a vector
  #num: the number of acceptable randomization vectors to generate
  #pw: proportion of units to be treated
  #normdis: '1', '2', 'I' (Infinite), 'H' (Hybrid: norm1 + sqrt(m)*norm_inf)
  #gamma1, gamma2: parameter in [0,1] for the one-infinity norm:
  #   one-inf norm = gamma1 * norm1 + gamma2 * sqrt(m) * norminf
  #pa: the acceptance probability.  A number for non-tiered or weighted tiers, a vector for restricted tiers
  #a: the cutoff threshold, either a number or vector.  either pa or a must be specified
  #print.progress: if true, prints "i" after completing W_i

  if (is.null(tprocs)) tprocs = 0
  if (is.null(a)) a = 1e+100
  if (is.null(pa)) pa = 1
  
  mintrials = round(1/pa)
  
  n = nrow(x)
  m = ncol(x)
  nt = round(n*pw)
  nc = n - nt
  
  # Inverse of cholesky factor of covariance of x
  invcholx = inverseCholCov(x)   # Caution: in R, chol(X) returns an upper triangular matrix
  z = as.matrix(x) %*% invcholx   # cov(z) =~ I


  # R and S: auxiliary matrix and vector used for computing the distances between covariate means  
  R = (nc+nt)/(nc*nt)*t(z)
  S = apply(z,2,sum)/nc
  
  # Sort time limits
	tprocs = sort(tprocs)
	qtt = length(tprocs)

	#browser()
	
  ######## DOING THE RERANDOMIZATION #########
  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
  #for(ids in 1:num) {
      
    #loop
    cur = Sys.time()
    bestD = 1e+100
    W.best = rep(0, n)
    
    # MatrAloc is an auxiliary matrix to hold the allocation vectors, processing times and distances. 
    # Each column corresponds to a time limit (secs) and the rows are organized as follows:
    #   1..n : binary allocations (0=control group, 1=treatment group)
    #   n+1 : total processing time
    #   n+2 : minimal distance (according to the norm specified by normdis string)
    #   n+3 : number of trials
    #   n+4 : norm L1 distance
    #   n+5 : norm L2 distance
    #   n+6 : norm Linf distance
    #   n+7 : hybrid norm distance
	  MatrAloc = matrix(0, nrow=n+7, ncol=qtt)
	  
	  idt = 1
	  trial = as.double(0.0)
	  while (idt<=qtt) {
      tprocatu = tprocs[idt]

		  accept = FALSE
		  while(!accept) {
		    trial = trial+1
		    W.temp = rep(0, n)
		    W.temp[sample(1:n, nt, replace=FALSE)]=1 

		    dmeans = R %*% W.temp - S

		    # computing distances without the normalizing constant (nc/n * nt) 
		    cur.dist = calc.dist(dmeans, normdis, gamma1, gamma2)

		    if (cur.dist<bestD) {
		      bestD = cur.dist
		      W.best = W.temp
		    }
		    rtime = as.numeric(difftime(Sys.time(), cur, units='secs'))
		    #### checking criteria ####
		    accept = (bestD <= a & rtime >= tprocatu & trial>=mintrials)
		  
		  }  # while(!accept)

		  if(print.progress) print(c(ids, bestD, rtime))
		  
		  dmeans = R %*% W.best - S
		  MatrAloc[,idt] = c(W.best, rtime, bestD, trial,
		                     calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
		                     calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2))
		  idt = idt+1

		} # while (idt<=qtt)
	  
	  MatrAloc
 
  } # foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE)
  
  if (num*qtt==1) Stats = matrix(Stats, ncol=1)

	W = list()
	times = list()
	dists = list()
	trials = list()
	distsL1 = list()
	distsL2 = list()
	distsLI = list()
	distsL1I = list()
	
	for (idt in 1:qtt) {
	  cols = (0:(num-1))*qtt+idt
	  W[[idt]] = Stats[1:n,cols]
	  times[[idt]] = Stats[n+1,cols]
	  dists[[idt]] = Stats[n+2,cols]
	  trials[[idt]] = Stats[n+3,cols]
	  distsL1[[idt]] = Stats[n+4,cols]
	  distsL2[[idt]] = Stats[n+5,cols]
	  distsLI[[idt]] = Stats[n+6,cols]
	  distsL1I[[idt]] = Stats[n+7,cols]
	}

  return(list(Stats=Stats, W=W, times=times, dists=dists, trials=trials, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I))
}
