# R multi core helper

suppressPackageStartupMessages(library(foreach))

# load doMC if not under windows
sysname = tolower(Sys.info()['sysname'])
proccores=1
if (!(sysname %in% c("windows", "darwin"))) {
    # Finding the number of available processor cores
    # load the package with function detectCores
    suppressPackageStartupMessages(library(parallel))   
    proccores=NULL
    proccores = try(detectCores(all.tests = FALSE, logical = TRUE))
    if (length(proccores)==0) {
      proccores=1
    }
    if ("package:doMC" %in% search()) {
      try(detach("package:doMC", unload=TRUE), silent=TRUE)  # unload doMC
    }
    try(detach("package:parallel", unload=TRUE), silent=TRUE)   # unload parallel
    
    suppressPackageStartupMessages(library(doMC))
    
    if(Sys.info()['sysname']=="hulk2") {
      registerDoMC(cores=16)
    } else {
      registerDoMC(cores=proccores)
      #registerDoMC(cores=1)
    }
}
