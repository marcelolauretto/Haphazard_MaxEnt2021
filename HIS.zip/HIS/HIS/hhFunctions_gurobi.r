###################
#
# Haphazard sampling
#
#


#require(robCompositions)
require(gurobi)

source('MultiCore.r')
source('rrFunctions_marc.r')

#
#  lambda: noise weight (0 < lambda < 1)
#  ma: number of columns in noise matrix
#  num: number of allocations
#  mipgap: relative gap between current and threshold distance
#  normdis: distance norm: '1' (Manhattan), '2' (Mahalanobis), 'I' (infinite, Max), 
#                          '1I' (0-Inf norm: norm1 + sqrt(m)*norm_inf)  
#  gamma1, gamma2: parameter in [0,1] for the one-infinity norm:
#                  one-inf norm = gamma1 * norm1 + gamma2 * sqrt(m) * norminf
#  a: distance threshold
#
hapsamplingGurobi = function(x, lambda=0.1, ma=2, num=1, pw=1/2, NoisesStd=NULL,
                             normdis='1', gamma1=0.5, gamma2=0.5,
                             a=NULL, tprocs=NULL, mipgap=0, print.progress=TRUE, vecini=NULL) {
  
  n = nrow(x)  
  m = ncol(x)    
  nt = round(n*pw)  
  nc = n - nt       

  if (is.null(tprocs)) tprocs = 1e+3
  if (is.null(NoisesStd)) {
    Noises = matrix(rnorm(ma*num*n), ncol=num)    
    NoisesStd = matrix(0, nrow=ma*n, ncol=num)    # Standardized Noises (A*)
    for (ids in 1:num) {
      A = matrix(Noises, ncol=ma, byrow=FALSE)
      invcholA = inverseCholCov(A)
      za = as.matrix(A) %*% invcholA
      # Matriz A* no artigo pg 2 (ruido)
      NoisesStd[,ids] = as.vector(za)
    }
    
  }
  

  # equation 10
  lambdamod = lambda/(lambda*(1-ma/m) + ma/m)  
  

  
  # Inverse of cholesky factor of covariance of x
  invcholx = inverseCholCov(x)   # Caution: in R, chol(X) returns an upper triangular matrix
  
  zx = as.matrix(x) %*% invcholx # A* Matrix  

  
  Rx = (nc+nt)/(nc*nt)*t(zx)
  Sx = apply(zx,2,sum)/nc
  
  #
  # Laco principal 
  # (todas as alocacoes/simulacoes em multicore)
  #
  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
    
    cur = Sys.time()

    if (print.progress) print(c(ids))
    #browser()

    # Standardized noise matrix
    za = matrix(NoisesStd[,ids], ncol=ma, byrow=FALSE)
    
    mz = m+ma #Number of columns in matrix with noises
    
    if (normdis == '2') {
      z = cbind(sqrt(lambdamod)*za, sqrt(1-lambdamod)*zx) 
    } else {
      z = cbind(lambdamod*za, (1-lambdamod)*zx) 
    }
    
    if(lambda==0){z=x}
    
  
    R = (nc+nt)/(nc*nt)*t(z)
    S = apply(z,2,sum)/nc

    # Sort time limits
    tprocs = sort(tprocs)
    qtt = length(tprocs)
    
    
    
    # Starting point #1000 alocs
    set.seed(ids)
    startingp = rerandomize.SSL(x=z, num=1, pw=pw, normdis=normdis, gamma1=gamma1, gamma2=gamma2, pa=0.001, print.progress=FALSE)
    wini = startingp$W[[1]]

    
    # MatrAloc is an auxiliary matrix to hold the allocation vectors, processing times and distances. 
    # Each column corresponds to a time limit (secs) and the rows are organized as follows:
    #   1..n : binary allocations (0=control group, 1=treatment group)
    #   n+1 : total processing time
    #   n+2 : minimal distance (according to the norm specified by normdis string)
    #   n+3 : norm L1 distance
    #   n+4 : norm L2 distance
    #   n+5 : norm Linf distance
    #   n+6 : hybrid norm distance
    MatrAloc = matrix(0, nrow=n+7, ncol=qtt)
    
    idt = 1
    trial = 0
    while (idt<=qtt) {
      tprocatu = tprocs[idt]

      dmeans = R %*% wini - S
      dini = calc.dist(dmeans, normdis, gamma1, gamma2)
      threshold = ifelse(is.null(a), mipgap*dini, (1-lambdamod)*a)
      
      model = list()
      if (normdis=='1') {  
        
        model$obj   = c(rep(0, n), rep(1,mz))
        
        model$A = matrix(0, nrow=2*mz+1, ncol=n+mz)
        model$A[1,1:n] = 1  # 1w = nt
        model$A[2:(mz+1), 1:n] = R
        diag(model$A[2:(mz+1), n+(1:mz)]) = -1
        model$A[(mz+1)+(1:mz), 1:n] = -R
        diag(model$A[(mz+1)+(1:mz), n+(1:mz)]) = -1
        
        model$rhs   = c(nt, S, -S)
        
        model$sense = c('=', rep('<=', 2*mz))
        model$vtype = c(rep('B', n), rep('C', mz))
        
        model$start = c(wini, abs(dmeans)) # Starting point
        
      } else if (normdis=='2') {
        
        # Matrix for quadratic component of objective function 
        model$Q = matrix(0, nrow=n+mz, ncol=n+mz)
        diag(model$Q)[n+(1:mz)] =1
        
        model$obj   = rep(0, n+mz)
        
        model$A = matrix(0, nrow=mz+1, ncol=n+mz)
        model$A[1,1:n] = 1  # 1w = nt
        model$A[2:(mz+1), 1:n] = R
        diag(model$A[2:(mz+1), n+(1:mz)]) = -1
        
        model$rhs   = c(nt, S)
        model$sense = rep('=', mz+1)
        model$vtype = c(rep('B', n), rep('C', mz))
        
        #model$start = c(wini, dmeans) # Starting point
        
      } else if (normdis=='I') {
        
        model$obj   = c(rep(0, n), 1)
        
        model$A = matrix(0, nrow=2*mz+1, ncol=n+1)
        model$A[1,1:n] = 1  # 1w = nt
        model$A[2:(mz+1), 1:n] = R
        model$A[2:(mz+1), n+1] = -1
        
        model$A[(mz+1)+(1:mz), 1:n] = -R
        model$A[(mz+1)+(1:mz), n+1] = -1
        
        model$rhs   = c(nt, S, -S)
        
        model$sense = c('=', rep('<=', 2*mz))
        model$vtype = c(rep('B', n), 'C')
        
        model$start = c(wini, max(abs(dmeans))) # Starting point
        
      } else {
        
        # min [ 0 ... 0 ] [gamma1 ... gamma1] [gamma2*sqrt(m)] * t([ w1 ... wn ] [ d1 ... dm] [ u ]) 
        model$obj   = c(rep(0, n), rep(gamma1,mz), gamma2*sqrt(m))
        
        #  [ 1 1 1 1 ... 1 ] [0 0 ... 0] [0]     | w1 |  =  | nt |
        #  [      R        ] [ -I(mz)  ] [0]     | w2 |  <= |  S |
        #  [     -R        ] [ -I(mz)  ] [0]  *  | .. |  <= | -S |
        #  [      0        ] [ -I(mz)  ] [1]     | wn |  >= |  0 |
        #                                        | d1 |
        #                                        | .. |
        #                                        | dm |
        #                                        | u  |
        
        model$A = matrix(0, nrow=3*mz+1, ncol=n+mz+1)
        # 1w = nt
        model$A[1,1:n] = 1  
        # Rw - d <= S
        model$A[2:(mz+1), 1:n] = R
        diag(model$A[2:(mz+1), n+(1:mz)]) = -1
        # -Rw - d <= -S 
        model$A[(mz+1)+(1:mz), 1:n] = -R
        diag(model$A[(mz+1)+(1:mz), n+(1:mz)]) = -1
        # -Id + u >= 0
        diag(model$A[(2*mz+1)+(1:mz), n+(1:mz)]) = -1
        model$A[(2*mz+1)+(1:mz), n+mz+1] = 1
        
        model$rhs   = c(nt, S, -S, rep(0, mz))
        
        model$sense = c('=', rep('<=', 2*mz), rep('>=', mz))
        model$vtype = c(rep('B', n), rep('C', mz), 'C')
        
        model$start = c(wini, abs(dmeans), max(abs(dmeans))) # Starting point

      }
      
      rtime = as.double(difftime(Sys.time(),cur,units='secs'))
      TimeLimit = max(c(1, tprocatu-rtime))
      
      params = list(MIPGapAbs=threshold, OutputFlag=0, TimeLimit=TimeLimit, Threads=1)
      resgur = gurobi(model, params)
      
      rtime = as.numeric(difftime(Sys.time(),cur,units='secs'))
      
      W.best = round(resgur$x[1:n],0)
      dmeans = Rx %*% W.best - Sx
      bestD = calc.dist(dmeans, normdis, gamma1, gamma2)
      
      mipgapabs<-resgur$mipgap*resgur$objval
      
      timeout = ifelse(resgur$status == "OPTIMAL", 0, 1)
      
      MatrAloc[,idt] = c(W.best, rtime, bestD, 
                         calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
                         calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2),mipgapabs)
      
      if (print.progress) print(c(ids, idt, rtime, bestD))
      
      #browser()

      wini = W.best 

      idt = idt+1
    } 
    
    MatrAloc
    
  }  # foreach
  
  qtt = 1
  
  if (num*qtt==1) Stats = matrix(Stats, ncol=1)
  
  W = list()
  times = list()
  dists = list()
  distsL1 = list()
  distsL2 = list()
  distsLI = list()
  distsL1I = list()
  mipgapABS = list()
  
  for (idt in 1:qtt) {
    cols = (0:(num-1))*qtt+idt
    W[[idt]] = Stats[1:n,cols]
    times[[idt]] = Stats[n+1,cols]
    dists[[idt]] = Stats[n+2,cols]
    distsL1[[idt]] = Stats[n+3,cols]
    distsL2[[idt]] = Stats[n+4,cols]
    distsLI[[idt]] = Stats[n+5,cols]
    distsL1I[[idt]] = Stats[n+6,cols]
    mipgapABS[[idt]] = Stats[n+7,cols]
  }
  
  return(list(Stats=Stats, W=W, times=times, dists=dists, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I, mipgapABS=mipgapABS))
  
}



