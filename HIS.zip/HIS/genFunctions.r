#########################
#
#  Haphazard Sampling and Resampling: General functions 
#  


#require(robCompositions)
require(psych)

source('MultiCore.r')



# Compute covariance of x and its inverse
inverseCov = function(x) {
  CovX = cov(x)
  cholCovX = chol(CovX)
  invchol = solve(cholCovX, diag(ncol(x)), tol=.Machine$double.eps*1e-5)
  ICovX = invchol %*% t(invchol) 
  return(ICovX)  
}


# Compute the inverse of Cholesky factor of the covariance matrix of x
inverseCholCov = function(x) {
  CovX = cov(x)
  cholCovX = chol(CovX)
  invchol = solve(cholCovX, diag(ncol(x)), tol=.Machine$double.eps*1e-5)
  return(invchol)  
}


# Convert the matrix of covariates to a standardized form
Std_Covariates = function (X, nt, nc) {

  # Inverse of cholesky factor of covariance of x
  invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
  Zx = as.matrix(X) %*% invcholx

  Rx = (nc+nt)/(nc*nt)*t(Zx)
  Sx = apply(Zx,2,sum)/nc
  
  return(list(Zx = Zx, Rx=Rx, Sx=Sx))
}


#
#  Distance computation under norms 1, 2, inf and 1-Inf
#
#  dmeans: vector of mean differences between groups
#  normdis: '1' = norm L1, '2' = norm L2, 'I' = norm Linf, 'I1' = hybrid norm 
calc.dist = function(dmeans, normdis, gamma1, gamma2) {
  return(
    ifelse(normdis=='1', sum(abs(dmeans)),                # norm 1
    ifelse(normdis=='2', sqrt(t(dmeans) %*% dmeans),     # norm 2
    ifelse(normdis=='I', max(abs(dmeans)),                # norm inf
    gamma1*sum(abs(dmeans)) + gamma2*sqrt(length(dmeans))*max(abs(dmeans))))) # 1-infinity norm
  )
} 




#
# Given a matrix of covariates X and a matrix of allocations W,  
# compute the standardized Mahalanobis distance for each allocation.
#
calc.M.std = function(X, W) {
  n = nrow(X)
  n1 = sum(W[,1])
  n0 = n-n1
  
  StdCov = Std_Covariates(X, n1, n0)
  
  MahaDist = rep(0, ncol(W))
  for(jj in 1:ncol(W))
  {
    dmeans = StdCov$Rx %*% W[,jj] - StdCov$Sx
    MahaDist[jj] = calc.dist(dmeans, normdis='2')
  }
  
  return(MahaDist)
}





#Create the noise matrices
# x is a numeric dataset/matrix
# mnoise is the number of columns in noise matrix
# nsim is the number of repetitions
Noise_Matrices<-function(x,mnoise,nsim){
    MatrNoises = matrix(rnorm(mnoise*nrow(x)*nsim), ncol=nsim) 
    MatrNoiseStd = matrix(0,nrow=mnoise*nrow(x), ncol=nsim)    # Standardized Noises
    for (ids in 1:nsim) {
      A = matrix(MatrNoises[,ids], ncol=mnoise, byrow=FALSE)
      invcholA = inverseCholCov(A)
      za = as.matrix(A) %*% invcholA
      MatrNoiseStd[,ids] = as.vector(za)
    }
    return(MatrNoiseStd)
}


