#
#   Allocations: Haphazard Intentional Sampling, rerandomization and pure Random
#

rm(list=ls())

library(dplyr)
source('hhFunctions_gurobi.r', encoding = "UTF-8")
source('genFunctions.r', encoding = "UTF-8")



#Output directory.
diretsai = 'output'
if (!file.exists(diretsai)) {
  dir.create(diretsai)
}


#Datasets.
dados<-read.table("POP_SET_HAPHAZARD_MUNI_EPICOVID19_20210526.txt", dec=".", header = T, sep = ";", fileEncoding = "latin1")
Qtset = read.table('20210209 - Quantidade de setores por municipio Epicovid19.txt', header=TRUE, sep = ";", fileEncoding = "latin1")



#Number of repetitions of the allocation procedure.
nsim=300

#Distance norms. 
normdists =  c('1I')  # c('1', '2', 'I', '1I')
normdis = normdists[1]  
gamma1 = gamma2 = 1 # Parameters for 1-Infinity Norm. See Ward and Wendel[11] 

#Processing time vector, according to the number of sectors in each municipality.
tprocsvec = c(rep(120,3),rep(30,127),rep(5,3))
qtt = length(tprocsvec)

# municipality index in '20210209 - Quantidade de setores por município Epicovid19.txt' dataset.
ind.mun<-c(1,2,3,30,60,90,120,131,132,133)


#Allocation routines
for(mm in ind.mun){

  # lambda is the disturbance parameter, ranging from 0 to 1. 
  # lambda = 1 stands for pure random method. 
  # lambda = 2 stands for rerandomization method.
  
  if(mm < 4){lambdas<-c(0.001,2)}
  if(mm >= 4 & mm < 130){lambdas<-c(0.01,2)}
  if(mm > 130){lambdas<-c(0.1,2)}
  qtlambdas<-length(lambdas)
  
  
  dadosmun<-dados[dados$COD_MUN == Qtset$X.U.FEFF.COD_MUN[mm],]
  municipio<-as.character(Qtset$MUNICIPIO[mm])
  
  varcont<-dadosmun[,8:22]
  varcont<-apply(apply(varcont, 2, gsub, patt=",", replace="."), 2, as.numeric)
  x<-as.data.frame(varcont)
  n = nrow(x)
  nt = 25 #Sample Size
  pw = nt/n   # proportion of selected elements
   

  #Noise Matrices 
  mnoise=2
  MatrNoiseStd<-Noise_Matrices(x,mnoise,nsim)
  
    
   tprocs<-tprocsvec[mm]
   
   tablist=list()

    for(idc in 1:qtlambdas){
    
      lambda = lambdas[idc]

      print(paste0("lambda = ",lambda," Municipio: ",as.character(Qtset$MUNICIPIO[mm])))
      
      if(lambda < 1){
      normdists =  c('1I') 
      Aloc = hapsamplingGurobi(x=x, lambda=lambda, ma=mnoise, num=nsim, pw=pw, 
                                      normdis=normdis, gamma1=gamma1, gamma2=gamma2, tprocs=tprocs, NoisesStd=MatrNoiseStd)
      }
      
      if(lambda == 1){
        normdists =  c('2')
      Aloc=rerandomize.SSL(x=x, num=nsim, pw=pw, normdis=normdis, gamma1=gamma1, gamma2=gamma2, pa=1, print.progress=T)  
      }
      
      if(lambda == 2){
      normdists =  c('2')
      Aloc=rerandomize.SSL(x=x, num=nsim, pw=pw, normdis=normdis, gamma1=gamma1, gamma2=gamma2, tprocs = tprocs, print.progress=T)  
      }
      
      nmarqaloca = paste(diretsai, '/', municipio, '_', lambda, '.txt', sep='')
      write.table(Aloc$Stats, file=nmarqaloca, sep='\t', col.names=FALSE, row.names=FALSE)
      
      }
} 


